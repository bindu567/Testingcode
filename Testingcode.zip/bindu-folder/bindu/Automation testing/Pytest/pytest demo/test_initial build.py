def test_smoketesting():
    print("this is smoke testing")
def test_sanitytesting():
    print("this is sanity testing")
    assert False
def test_endtoendtesting():
    print("this is endtoend testing")
def test_regressiontesting():
    print("this is regression testing")
import pytest
def test_methodA():
    print("this is method A")
@pytest.mark.skip
def test_methodB():
    print("this is method B")
@pytest.mark.xfail
def test_methodC():
    print("this is method C")
@pytest.mark.xfail
def test_methodD():
    print("this is method D")
    assert False

def test_methodE():
    print("this is method E")

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class Testhollandbarrett:
    @pytest.fixture()
    def setup(self):
        self.driver=webdriver.Chrome()
        self.driver.maximize_window()
        yield
        self.driver.close()
    def test_homepagetitle(self,setup):
        self.driver.get("https://auth.hollandandbarrett.com/u/login")
        time.sleep(5)
        assert self.driver.title== "Sign in - to your account, for the best experience"
    def test_login(self,setup):
        self.driver.get("https://auth.hollandandbarrett.com/u/login")
        self.driver.find_element(By.ID,"username").send_keys("bindhi@gmail.com")
        self.driver.find_element(By.ID, "password").send_keys("Ch@56789")
        self.driver.find_element(By.XPATH, "/html/body/main/section/div/div/div/form/div[2]/button").click()
        assert self.driver.title


import pytest
@pytest.mark.profile
def test_methodA():
    print("this is method A")

@pytest.mark.profile
def test_methodB():
    print("this is method A")

@pytest.mark.feeds
def test_example1():
    print("this is example1")

@pytest.mark.feeds
def test_example2():
    print("this is example2")
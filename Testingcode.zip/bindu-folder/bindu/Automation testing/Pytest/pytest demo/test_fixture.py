import pytest
#like login method
@pytest.fixture
def fixtureMethod():
    print("this is fixture method")

def test_login():
    print("this is method A")
def test_search(fixtureMethod):
    print("this is method B")
def test_addtocart(fixtureMethod):
    print("this is method C")
def test_payment(fixtureMethod):
    print("this is method D")
def test_placeorder(fixtureMethod):
    print("this is method D")


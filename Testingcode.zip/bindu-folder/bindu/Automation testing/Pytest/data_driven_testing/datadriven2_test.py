import time
from fileinput import filename

from selenium import webdriver
from selenium.webdriver.common.by import By
import XLUtilities

driver=webdriver.Chrome()
driver.get("https://auth.hollandandbarrett.com/u/login")
driver.maximize_window()
time.sleep(5)

path="C://selenium practice/holland barrett.xlsx"
rows=XLUtilities.getrowcount(path,"Sheet1")

for r in range(2,rows+1):
    username=XLUtilities.readData(path,'Sheet1',r,1)
    password = XLUtilities.readData(path, "Sheet1",r,2)

    driver.find_element(By.NAME,'username').send_keys(username)
    driver.find_element(By.NAME, 'password').send_keys(password)
    driver.find_element(By.XPATH, '/html/body/main/section/div/div/div/form/div[2]/button').click()
    time.sleep(5)

    driver.find_element(By.XPATH, '//*[@id="Icon"]').click()
    driver.find_element(By.XPATH, '//*[@id="__next"]/main/div[1]/div/div[2]/div/div/div[3]/button').click()
    time.sleep(5)
    driver.find_element(By.XPATH, '//*[@id="_root_"]/div[1]/div[3]/div[1]/div[2]/a/svg').click()


    if driver.title=="Sign in - to your account, for the best experience":
        print("test is passed")
        XLUtilities.writeData(path,"Sheet1",r,3,"Passed")
    else:
        print("test is failed")
        XLUtilities.writeData(path, "Sheet1", r, 3, "Failed")




import time
from selenium import webdriver
import unittest
from POM.login_page import LoginPage

class LoginTests(unittest.TestCase):
    def test_validlogin(self):
        driver = webdriver.Chrome()
        driver.get("https://auth.hollandandbarrett.com/u/login")
        driver.maximize_window()
        time.sleep(1)

        lp=LoginPage(driver)    -
        lp.login("bindhi@gmail.com","Ch@56789")
        time.sleep(15)

        actual_title = driver.title
        expect_title = "Sign in - to your account, for the best experience"

        if actual_title == expect_title:
            print("login is successful")
        else:
            print("login is  not successful")
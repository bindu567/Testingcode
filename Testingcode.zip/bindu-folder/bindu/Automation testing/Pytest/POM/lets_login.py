from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import pytest


class Letslogin():
    def __init__(self, driver):
        self.driver = driver

    _email = "email"
    _password = "login-password"
    _login = "/html/body/main/section/div/div/div/form/div[2]/button"

    def Email(self):
        return self.driver.find_element(By.ID, self._email)

    def Password(self):
        return self.driver.find_element(By.ID, self._password)

    def Loginbutton(self):
        return self.driver.find_element(By.XPATH, self._login)

    def enterEmail(self, email):
        self.Email().send_keys(email)

    def enterPassword(self, password):
        self.Password().send_keys(password)

    def clicklogin(self):
        self.Loginbutton().click()

    def login(self, email, password):
        self.enterEmail(email)
        self.enterPassword(password)
        self.clicklogin()



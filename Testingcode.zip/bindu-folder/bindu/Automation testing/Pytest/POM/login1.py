import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class Add_to_cart():

    def __init__(self,driver):
        self.driver = driver


    _vitamin_btn="//button[normalize-space()='Vitamins']"
    _veganChocolate_btn="//button[normalize-space()='Vegan Chocolate']"
    _vitaminC_btn ="//div[normalize-space()='Vitamin C']"
    _ProductVC_btn="//a[1]//div[1]//div[3]//div[2]//button[1]"
    _ProductVG_btn="//a[1]//div[1]//div[3]//div[2]//button[1]"


    def getVitaminandSupplements(self):
        partial_link = "Vitamins"
        self.driver.find_element(By.PARTIAL_LINK_TEXT, partial_link).click()

    def getVitamins(self):
        return self.driver.find_element(By.XPATH, self._vitamin_btn)

    def getVitaminC(self):
        return self.driver.find_element(By.XPATH, self._vitaminC_btn)

    def AddvitaminC(self):
        return self.driver.find_element(By.XPATH, self._ProductVC_btn)

    def Clickvitmins(self):
        self.getVitamins().click()

    def clickvitaminC(self):
        self.getVitaminC().click()

    def clickAdditems(self):
        self.AddvitaminC().click()


    def getVegan(self):
        partial_link = "Vegan"
        self.driver.find_element(By.PARTIAL_LINK_TEXT, partial_link).click()

    def getVeganChocolate(self):
        return self.driver.find_element(By.XPATH,self._veganChocolate_btn)

    def Addveganchoc(self):
        return not self.driver(By.XPATH,self._ProductVG_btn)

    def clickvgchoc(self):
        self.getVeganChocolate().click()

    def clickAddvg(self):
        self.Addveganchoc().click()
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class Add_to_cart():

    def __init__(self,driver):
        self.driver = driver

    vitandsup="/html/body/div[1]/div[3]/div[4]/a"
    vitamin="//button[normalize-space()='Vitamins']"
    vitC = "//div[normalize-space()='Vitamin C']"
    vegchoc="//button[normalize-space()='Vegan Chocolate']"

    addvitC="//a[1]//div[1]//div[3]//div[2]//button[1]"
    addvegchoc="//a[1]//div[1]//div[3]//div[2]//button[1]"


    def getVitandSupp(self):

         return self.driver.find_element(By.XPATH, self.vitandsup).click()

    def getVita(self):
        return self.driver.find_element(By.XPATH, self.vitamin)

    def getVitaC(self):
        return self.driver.find_element(By.XPATH, self.vitC)

    def addvitaC(self):
        return self.driver.find_element(By.XPATH, self.addvitC)

    def clickvita(self):
        self.getVita().click()

    def clickvitaC(self):
        self.getVitaC().click()

    def clickaddvitC(self):
        self.addvitaC().click()


    def getvegan(self):
        partial_link = "Vegan"
        self.driver.find_element(By.PARTIAL_LINK_TEXT, partial_link).click()

    def getvegcho (self):
        return self.driver.find_element(By.XPATH,self.vegchoc)

    def addveganchoc(self):
        return not self.driver(By.XPATH,self.addvegchoc)

    def clickvgchoc(self):
        self.getvegcho().click()

    def clickaddvg(self):
        self.addveganchoc().click()

    def basket(self):
        self.getVitandSupp()
        self.getVita()
        self.getVitaC()
        self.clickvita()
        self.clickvitaC()
        self.clickaddvitC()
        self.clickvgchoc()
        self.addvitaC()
        self.addveganchoc()


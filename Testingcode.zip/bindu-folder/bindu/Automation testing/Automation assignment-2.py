
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1.Open the website
driver=webdriver.Chrome()
driver.get("https://www.hollandandbarrett.com/en-au/")
driver.maximize_window()
driver.save_screenshot(".//website opened.png")
time.sleep(5)

#homepage
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/div[3]/div/div[2]/div/div/button").click()
time.sleep(5)
# 2.Click on Rewards section. (Note: Creating an account directly throws an error, instead click on any sections eg: Rewards, store will be helpful to create an account, Website maintenance issue)
#rewards
edit_box=driver.find_element(By.XPATH,"//h3[normalize-space()='Rewards for Life']").click()
driver.save_screenshot(".//Rewards section.png")
time.sleep(5)
# 3.Click on account and then“Create account”
#join for rewards
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/div[5]/div/div/div/button").click()
driver.save_screenshot(".//Join for creating account.png")
time.sleep(5)
# 4. Register for an account, please update the details.
#account creating details
edit_box=driver.find_element(By.ID,"firstName").send_keys("bindu")
time.sleep(5)
edit_box=driver.find_element(By.ID,"lastName").send_keys("d")
time.sleep(5)
edit_box=driver.find_element(By.ID,"email").send_keys("bindhi@gmail.com")
time.sleep(5)
edit_box=driver.find_element(By.ID,"confirmEmail").send_keys("bindhi@gmail.com")
time.sleep(5)
edit_box=driver.find_element(By.ID,"password").send_keys("Ch@56789")
driver.save_screenshot(".//Entered details.png")
time.sleep(5)
#terms and conditions
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/article/section/form/label/input").click()
time.sleep(5)
#create you account button
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/article/section/form/button/span").click()
driver.save_screenshot(".//Account has been created.png")
time.sleep(5)

# 5. Verify whether the account has been created.
#checking account creation through login
driver.get("https://auth.hollandandbarrett.com/u/login")
time.sleep(5)

edit_box=driver.find_element(By.ID,"username").send_keys("bindhi@gmail.com")
time.sleep(5)
edit_box=driver.find_element(By.NAME,"password").send_keys("Ch@56789")
time.sleep(5)
#login button
edit_box=driver.find_element(By.XPATH,"/html/body/main/section/div/div/div/form/div[2]/button").click()
driver.save_screenshot(".//Login page.png")
time.sleep(5)


#2nd test case
# 1. Open the website.
#open website
driver.get("https://www.hollandandbarrett.com/")
driver.save_screenshot(".//Website opened.png")
time.sleep(5)
#2. Login with the registered user.
#while script is running, access is being denied, so we directly used the URL
#3. Add any Vitamin C products from 'Vitamins & Supplements' to the basket.
#vitamins and supplements
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/div[3]/div[4]/a").click()
time.sleep(5)
#vitamins
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/div[4]/div[3]/a/button").click()
time.sleep(5)
#vitamin C
edit_box=driver.find_element(By.XPATH,"/html/body/div[2]/div[6]/div/div/div[1]/a[4]/div[2]").click()
time.sleep(5)
#add to basket
edit_box = driver.find_element(By.XPATH, "/html/body/div[2]/div[10]/div/div/div/div[3]/a[1]/div/div[3]/div[2]/button").click()
time.sleep(5)
driver.implicitly_wait(5)
driver.execute_script("window.scrollBy(0,-1000);")
driver.save_screenshot(".//VitaminC added.png")
time.sleep(5)

#4. Add any Vegan Chocolate products from 'Vegan' to the basket.
#vegan
driver.get("https://www.hollandandbarrett.com/")
time.sleep(5)
#vegan snacks
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/div[3]/div[8]/a").click()
time.sleep(5)
#vegan chocolate
edit_box=driver.find_element(By.XPATH,"/html/body/div[1]/div[4]/div[7]/a/button").click()
time.sleep(5)
#add to basket
edit_box=driver.find_element(By.XPATH,"/html/body/div[2]/div[10]/div/div/div/div[3]/a[1]/div/div[3]/div[2]/button").click()
time.sleep(5)
#5. Verify both the products are added to the basket.
driver.implicitly_wait(5)
driver.execute_script("window.scrollBy(0,-1000);")
driver.save_screenshot(".//Both the products are added to the basket.png")

from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from Assignment3 import XLUtilities1

#1. Open URL on chrome
driver=webdriver.Chrome()
driver.get("https://demo.opencart.com.gr/")
driver.maximize_window()
time.sleep(5)

#2. Verify if the title "Your Store" of the application is correct
actual_title="Your Store"
expect_title=driver.title
if(actual_title==expect_title):
    print(" Application Title is verified")
else:
    print("Application Title is verified")

# 3. Click on "My Account" menu option
edit_box=driver.find_element(By.XPATH,'//*[@id="top-links"]/ul/li[2]/a/i').click()
time.sleep(5)

# 4.Select "Register" option
edit_box=driver.find_element(By.XPATH,'//*[@id="top-links"]/ul/li[2]/ul/li[1]/a').click()
time.sleep(5)

# 5.Verify the text present on web page as "Register Account"
actual_title="Register Account"
expect_title=driver.title
if(actual_title==expect_title):
    print(" Register account Title is verified")
else:
    print(" Register account Title is verified")

# 6. Enter all the details in the First_name, Last_Name, E-Mail, Telephone, Password and Password Confirm from the excel sheet (UserDetails.xls)
path="C://selenium practice/Userdetails.xlsx"
rows= XLUtilities1.getrowcount(path, "Sheet1")

for r in range(2,rows+1):
    firstname= XLUtilities1.readData(path, 'Sheet1', r, 1)
    lastname = XLUtilities1.readData(path, "Sheet1", r, 2)
    email = XLUtilities1.readData(path, 'Sheet1', r, 3)
    telephone = XLUtilities1.readData(path, 'Sheet1', r, 4)
    password = XLUtilities1.readData(path, 'Sheet1', r, 5)
    passwordconfirm = XLUtilities1.readData(path, 'Sheet1', r, 6)


    driver.find_element(By.ID,'input-firstname').send_keys(firstname)
    driver.find_element(By.ID, 'input-lastname').send_keys(lastname)
    driver.find_element(By.ID, 'input-email').send_keys(email)
    driver.find_element(By.NAME, 'telephone').send_keys(password)
    driver.find_element(By.NAME, 'password').send_keys(password)
    driver.find_element(By.NAME, 'confirm').send_keys(passwordconfirm)

    # 7. Select "I have read and agree to the Privacy Policy" check box
    driver.find_element(By.XPATH, '//*[@id="content"]/form/div/div/input[1]').click()

    #8. Click on continue button
    driver.find_element(By.XPATH, '//*[@id="content"]/form/div/div/input[2]').click()
    time.sleep(15)

    # 9. Verify the acknowlwdgement message "Your account has been created"
    if driver.title=="Your Account Has Been Created!":
        print("test is passed")
        XLUtilities1.writeData(path, "Sheet1", r, 7, "Passed")
    else:
        print("test is failed")
        XLUtilities1.writeData(path, "Sheet1", r, 7, "Failed")






